<?php
/*
	License Text
 */
namespace Auther\PluginName;

use pocketmine\plugin\PluginBase;

class MainClass extends PluginBase {

	public function onEnable() {
		//codes
	}
}