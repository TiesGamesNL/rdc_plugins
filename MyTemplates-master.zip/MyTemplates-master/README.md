# My-Template-for-PMMP
This repo is put my style templates of plugin for PocketMine-MP. (for php7)

## License
These templates are licensed under the MIT License.  
About license for details, see the LICENSE file or the following url.

License text (original)  
https://opensource.org/licenses/mit-license.php