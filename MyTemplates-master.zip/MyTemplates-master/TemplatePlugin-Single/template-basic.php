<?php
/**
 * (Description)
 * @name (PluginName)
 * @main (Auther)\(PluginName)\MainClass
 * @version 1.0.0
 * @api 2.0.0
 * @author (Auther)
 */
namespace Auther\PluginName {//fix
	use pocketmine\plugin\PluginBase;

	class MainClass extends PluginBase {
		public function onEnable(){
			//codes
		}
	}
}